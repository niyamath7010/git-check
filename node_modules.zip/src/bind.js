

function Bild(props){
    return(
        <>
            {props.text}
            hwllo world
        </>
    )
}

export default Bild;