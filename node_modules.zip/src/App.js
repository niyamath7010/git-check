import React, { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation, Pagination, Controller, Thumbs } from 'swiper';
import 'swiper/swiper-bundle.css';
import './App.css';

function App() {
  return (
    <>
      <div className=''>
        <Swiper >


        </Swiper>
      </div>
    </>
  );
}

export default App;
