


function Appended(props){
    
    return (
        <>
            <div className="main_div">
                {props.text}
            </div>
        </>
    )
}

export default Appended;